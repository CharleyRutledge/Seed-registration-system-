﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2Seeds
{
    [Serializable]
    public class Seed : ICloneable
    {
       
       
        public int seedId { get; set; }
        public string seedname { get; set; }
        public int NoOfSeeds { get; set; }

        public List<int> SowMonths { get; set; }
        public List<int> FlowerMonths { get; set; }

        public string FlowerMonthDisplay { get; set; }
        public string SowMonthDisplay { get; set; }
        public string OtherInfo { get; set; }

      
        public Seed() { SowMonths = new List<int>(); FlowerMonths = new List<int>();  }

        public Seed(int sid, String name, int NoOfSeeds, List <int>SowMths, List<int> FlowerMths, String OtherInfo)
        {
            this.seedId = sid;
            this.seedname = name;
            this.NoOfSeeds = NoOfSeeds;
            this.SowMonths = SowMths;
            this.FlowerMonths = FlowerMths;
            this.OtherInfo = OtherInfo;

            foreach (int monthInt in SowMths)
            {
                this.SowMonthDisplay += CultureInfo.CurrentCulture.DateTimeFormat.GetAbbreviatedMonthName(monthInt) + " ";

            }

            foreach (int monthInt in FlowerMths)
            {
                this.FlowerMonthDisplay += CultureInfo.CurrentCulture.DateTimeFormat.GetAbbreviatedMonthName(monthInt) + " ";
            }
        }

        public object Clone()
        {
            return MemberwiseClone();
           
            
        }
    }
}
