﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.RegularExpressions;

namespace Lab2Seeds
{
    
    public partial class Form1 : Form
    {
        //creating a list called SeedDS that contains the definitions from Seed class
        List<Seed> SeedDS = new List<Seed>();

        // name of the file to be stored 
        string curFile = "Seed.txt";

        public Form1()
        {
            InitializeComponent();
        }


        //variables storing the index of where the button need to go.
        private const int ModifyIndex = 6;
        private const int DeleteIndex = 7;

        //getter/setter for add seed
        public bool AddSeed { get; set; }

        // get set for accessing seeds inside the object seed
        public Seed Seed { get; set; }


        private Seed selectedSeed;

        //--------------------------
        //Function to display seeds
        private void DisplaySeeds()
        {

            //modify the data list columns
           //---Clears the colums and sets the data source as null
            dataGridViewSeedList.Columns.Clear();
            dataGridViewSeedList.DataSource = null;

            //--- The data source is then set to the Seed Data base
            dataGridViewSeedList.DataSource = SeedDS;
            //---names the header text in Seed name is "Name"
            dataGridViewSeedList.Columns["SeedName"].HeaderText = "Name";


            //---Creates a data grid button called edit button
            DataGridViewButtonColumn editbutton =
            new DataGridViewButtonColumn();

            //---Sets the name, text, sets the use of the button to true and inserts it into the the Datagrid
            editbutton.Text = "Edit";
            editbutton.HeaderText = "Edit";
            editbutton.UseColumnTextForButtonValue = true;
            dataGridViewSeedList.Columns.Insert(ModifyIndex, editbutton);

            //--- Creates a delete button, the use of the button, the Deader text, the name and the text 
            //--This button is also inserted into the columns
            var DeleteColumn = new DataGridViewButtonColumn()
            {
                UseColumnTextForButtonValue = true,
                HeaderText = "Delete",
                Text = "Delete",
                Name = "colDelete"
            };
            dataGridViewSeedList.Columns.Insert(DeleteIndex, DeleteColumn);
        }



        private void Form1_Load(object sender, EventArgs e)
        {

            //To test data please comment out the hardcoded value and load the 
            //data with the load data button
            //set up data

            //---Seeds are inserted up the load of the form
            Seed s1 = new Seed(1, "Lavender 'Munstead'", 110, new List<int> { 2, 3, 4, 5, 6 }, new List<int> { 7, 8 }, "Hedges, Cottage Gardens, Scented Gardens, Wildlife Gardens, Cut Flower Garden");
            Seed s2 = new Seed(2, "Poppy (Wild)", 2000, new List<int> { 3, 4, 5 }, new List<int> { 6, 7, 8 }, "Cottage Gardens, Wildlife Gardens, Low Maintenance Garden");
            Seed s3 = new Seed(3, "Nicotiana alata ", 2000, new List<int> { 3, 4, 5 }, new List<int> { 7, 8, 9 }, "Half - Hardy Annual");
            Seed s4 = new Seed(4, "Daucus carota ", 100, new List<int> { 2, 4, 9, 10 }, new List<int> { 8, 9 }, "Full Sun");
            Seed s5 = new Seed(5, "Borage", 75, new List<int> { 2, 5 }, new List<int> { 5, 6 }, "Kew Pollination Collection");
            Seed s6 = new Seed(6, "Ammi Majus ", 100, new List<int> { 4, 6 }, new List<int> { 6, 8 }, "Cottage Gardens, Wildlife Gardens, Low Maintenance Garden");
            Seed s7 = new Seed(7, "Stock 'Night Scented'", 200, new List<int> { 3, 5 }, new List<int> { 6, 9 }, "attract and support a wide range of pollinators, including bees, butterflies and beetles");
            Seed s8 = new Seed(8, "Bee Balm ", 75, new List<int> { 9, 3 }, new List<int> { 6, 8 }, "Bee Balm is a magnet for pollinating insects, which throng to the nectar rich blooms.");
            Seed s9 = new Seed(9, "Malva Moschata 'Snow White'", 40, new List<int> { 2, 11 }, new List<int> { 6, 9 }, " is a dwarf variety producing masses of gleaming white flowers with delicate pale pink stamens in late summer. ");
            Seed s10 = new Seed(10, "Knapweed", 300, new List<int> { 3, 11 }, new List<int> { 7, 8 }, "particularly attractive to butterflies");


            SeedDS.Add(s1);
            SeedDS.Add(s2);
            SeedDS.Add(s3);
            SeedDS.Add(s4);
            SeedDS.Add(s5);
            SeedDS.Add(s6);
            SeedDS.Add(s7);
            SeedDS.Add(s8);
            SeedDS.Add(s9);
            SeedDS.Add(s10);

            //displays the seeds
            DisplaySeeds();

        }

        //adds a new seed to the list by creating a new list and calls a new form where detailsa re entered into and submitted into the seedsD
        private void btnAdd_Click(object sender, EventArgs e)
        {
            Seed SeedDetails = new Seed();
            var SeedForm = new AddModifySeedForm()
            {
                AddSeed = true
            };

            DialogResult selectedButton = SeedForm.ShowDialog();

            if (selectedButton == DialogResult.OK)
            {
                SeedDetails = SeedForm.Seed;

                SeedDS.Add(SeedDetails);

                DisplaySeeds();

            }
        }
        //captures the click funtion for the modify and delete button
        private void dataGridViewSeedList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            if (e.RowIndex >= 0)
            {
                selectedSeed = (Seed)dataGridViewSeedList.CurrentRow.DataBoundItem;


                if (e.ColumnIndex == ModifyIndex)
                {
                    MessageBox.Show("Modify " + selectedSeed.seedname);
                    ModifySeed();
                }
                if (e.ColumnIndex == DeleteIndex)
                {
                    DeleteSeed();
                }
            }
        }
        //Delete funtion
        private void DeleteSeed()
        {
            DialogResult result =
            MessageBox.Show($"Delete{selectedSeed.seedname }?",
      "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                SeedDS.Remove(selectedSeed);
                DisplaySeeds();

            }


        }

        //Modify the seed entry function
        private void ModifySeed()
        {

            var AddModifySeedForm = new AddModifySeedForm()
            {
                AddSeed = false,
                Seed = selectedSeed,
            };

            DialogResult result = AddModifySeedForm.ShowDialog();
            if (result == DialogResult.OK)
            {
                selectedSeed = AddModifySeedForm.Seed;
                DisplaySeeds();
            }


        }

        //copy function where the row selected is copied to the bottom of the list
        private void btnCopy_Click(object sender, EventArgs e)
        {

            DialogResult result = MessageBox.Show($"Copy{selectedSeed.seedname }?",
      "Confirm Copy", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                selectedSeed = (Seed)dataGridViewSeedList.CurrentRow.DataBoundItem;
                Seed s = (Seed)selectedSeed.Clone();
                s.seedId = SeedDS.Count() + 1;
                SeedDS.Add(s);
                DisplaySeeds();
            }
        }

        //exit function
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        //save button which calls the write data to file function
        private void btnSave_Click(object sender, EventArgs e)
        {

            writeDataToFile(SeedDS, curFile);
           
        }

        private void tbPQuery_Click(object sender, EventArgs e)
        {

        }

        private void lblSowMonths_Click(object sender, EventArgs e)
        {

        }

        //query function
        private void btnQuery_Click(object sender, EventArgs e)
        {
            //if the user enters in 0 or a value greater than 13 then an error is displayed
            int month = Convert.ToInt32(textBox1.Text);

            if (month == 0 || month > 12)
            {
                MessageBox.Show("please enter a number greater than 0 and less than 13");

            }


            //query
            var result = SeedDS.OrderBy(o => o.seedname)
                .Where(o => o.SowMonths.Contains(month))
                .Select(s => new
                {
                    s.seedname,
                    s.NoOfSeeds,
                    s.FlowerMonthDisplay,
                    s.SowMonthDisplay,
                    s.OtherInfo,
                }
                ).ToList();
            dgvQuery.DataSource = result.ToList();


        }
       //load data from file  then display seeds
        private void btnLoadData_Click(object sender, EventArgs e)
        {
            ReadDatafromFile(ref SeedDS, curFile);
            DisplaySeeds();

        }

        //read data from file function
        public static void ReadDatafromFile(ref List<Seed> l, string curFile)
        {
            
            List<Seed> temp = new List<Seed>();

            FileInfo fInfo = new FileInfo(curFile);
            FileStream seedsFile;

            if (fInfo.Exists)
            {
                seedsFile = new FileStream(curFile, FileMode.Open, FileAccess.Read);
                MessageBox.Show("found file for read " + fInfo.FullName);
                BinaryFormatter bformatter = new BinaryFormatter();
                try
                {
                    temp = (List<Seed>)bformatter.Deserialize(seedsFile);
                    l = temp;

                }
                catch (Exception e)
                {
                    MessageBox.Show("{0} Exception caught." + e);
                }
                seedsFile.Close();
            }
            else
            {
                MessageBox.Show("ERROR CANT FIND FILE " + fInfo.FullName);
            }

            MessageBox.Show("data read");
        }
        
        //write data to file function
        public static void writeDataToFile(List<Seed> l, string curFile)
        {

            FileInfo fInfo = new FileInfo(curFile);
            FileStream SeedFile;

            if (fInfo.Exists)
            {
                SeedFile = new FileStream(curFile, FileMode.Truncate, FileAccess.Write);
                MessageBox.Show("found file " + fInfo.FullName);
            }
            else
            {
                SeedFile = new FileStream(curFile, FileMode.Create, FileAccess.Write);
                MessageBox.Show("created file " + fInfo.FullName);
            }

            BinaryFormatter bformatter = new BinaryFormatter();

            try
            {
                bformatter.Serialize(SeedFile, l);


            }
            catch (Exception e)
            {
                Console.WriteLine("{0} Exception caught.", e);
            }

            SeedFile.Close();

            Console.WriteLine("data written to file");


        }

    }








}

        

