﻿
namespace Lab2Seeds
{
    partial class AddModifySeedForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSeedName = new System.Windows.Forms.Label();
            this.lblNoOfSeeds = new System.Windows.Forms.Label();
            this.lblSowMonths = new System.Windows.Forms.Label();
            this.lblFlowerMonths = new System.Windows.Forms.Label();
            this.lblAdditionalInformation = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtSeedName = new System.Windows.Forms.TextBox();
            this.txtNoOfSeeds = new System.Windows.Forms.TextBox();
            this.rtbAdditionalInformation = new System.Windows.Forms.RichTextBox();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.checkedListBox2 = new System.Windows.Forms.CheckedListBox();
            this.SuspendLayout();
            // 
            // lblSeedName
            // 
            this.lblSeedName.AutoSize = true;
            this.lblSeedName.Location = new System.Drawing.Point(52, 32);
            this.lblSeedName.Name = "lblSeedName";
            this.lblSeedName.Size = new System.Drawing.Size(103, 25);
            this.lblSeedName.TabIndex = 0;
            this.lblSeedName.Text = "Seed Name";
            // 
            // lblNoOfSeeds
            // 
            this.lblNoOfSeeds.AutoSize = true;
            this.lblNoOfSeeds.Location = new System.Drawing.Point(52, 80);
            this.lblNoOfSeeds.Name = "lblNoOfSeeds";
            this.lblNoOfSeeds.Size = new System.Drawing.Size(154, 25);
            this.lblNoOfSeeds.TabIndex = 1;
            this.lblNoOfSeeds.Text = "Number Of Seeds";
            // 
            // lblSowMonths
            // 
            this.lblSowMonths.AutoSize = true;
            this.lblSowMonths.Location = new System.Drawing.Point(52, 142);
            this.lblSowMonths.Name = "lblSowMonths";
            this.lblSowMonths.Size = new System.Drawing.Size(112, 25);
            this.lblSowMonths.TabIndex = 2;
            this.lblSowMonths.Text = "Sow Months";
            // 
            // lblFlowerMonths
            // 
            this.lblFlowerMonths.AutoSize = true;
            this.lblFlowerMonths.Location = new System.Drawing.Point(199, 142);
            this.lblFlowerMonths.Name = "lblFlowerMonths";
            this.lblFlowerMonths.Size = new System.Drawing.Size(130, 25);
            this.lblFlowerMonths.TabIndex = 3;
            this.lblFlowerMonths.Text = "Flower Months";
            this.lblFlowerMonths.Click += new System.EventHandler(this.label4_Click);
            // 
            // lblAdditionalInformation
            // 
            this.lblAdditionalInformation.AutoSize = true;
            this.lblAdditionalInformation.Location = new System.Drawing.Point(366, 142);
            this.lblAdditionalInformation.Name = "lblAdditionalInformation";
            this.lblAdditionalInformation.Size = new System.Drawing.Size(193, 25);
            this.lblAdditionalInformation.TabIndex = 4;
            this.lblAdditionalInformation.Text = "Additional Information";
            // 
            // btnConfirm
            // 
            this.btnConfirm.Location = new System.Drawing.Point(27, 566);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(112, 34);
            this.btnConfirm.TabIndex = 5;
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(176, 566);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(112, 34);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // txtSeedName
            // 
            this.txtSeedName.Location = new System.Drawing.Point(176, 29);
            this.txtSeedName.Name = "txtSeedName";
            this.txtSeedName.Size = new System.Drawing.Size(195, 31);
            this.txtSeedName.TabIndex = 7;
            // 
            // txtNoOfSeeds
            // 
            this.txtNoOfSeeds.Location = new System.Drawing.Point(221, 77);
            this.txtNoOfSeeds.Name = "txtNoOfSeeds";
            this.txtNoOfSeeds.Size = new System.Drawing.Size(150, 31);
            this.txtNoOfSeeds.TabIndex = 8;
            // 
            // rtbAdditionalInformation
            // 
            this.rtbAdditionalInformation.Location = new System.Drawing.Point(366, 190);
            this.rtbAdditionalInformation.Name = "rtbAdditionalInformation";
            this.rtbAdditionalInformation.Size = new System.Drawing.Size(333, 234);
            this.rtbAdditionalInformation.TabIndex = 9;
            this.rtbAdditionalInformation.Text = "";
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sept",
            "Oct",
            "Nov",
            "Dec"});
            this.checkedListBox1.Location = new System.Drawing.Point(37, 190);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(112, 340);
            this.checkedListBox1.TabIndex = 10;
            this.checkedListBox1.SelectedIndexChanged += new System.EventHandler(this.checkedListBox1_SelectedIndexChanged);
            // 
            // checkedListBox2
            // 
            this.checkedListBox2.FormattingEnabled = true;
            this.checkedListBox2.Items.AddRange(new object[] {
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sept",
            "Oct",
            "Nov",
            "Dec"});
            this.checkedListBox2.Location = new System.Drawing.Point(208, 190);
            this.checkedListBox2.Name = "checkedListBox2";
            this.checkedListBox2.Size = new System.Drawing.Size(112, 340);
            this.checkedListBox2.TabIndex = 11;
            // 
            // AddModifySeedForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 612);
            this.Controls.Add(this.checkedListBox2);
            this.Controls.Add(this.checkedListBox1);
            this.Controls.Add(this.rtbAdditionalInformation);
            this.Controls.Add(this.txtNoOfSeeds);
            this.Controls.Add(this.txtSeedName);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.lblAdditionalInformation);
            this.Controls.Add(this.lblFlowerMonths);
            this.Controls.Add(this.lblSowMonths);
            this.Controls.Add(this.lblNoOfSeeds);
            this.Controls.Add(this.lblSeedName);
            this.Name = "AddModifySeedForm";
            this.Text = "AddModifySeedForm";
            this.Load += new System.EventHandler(this.AddModifySeedForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSeedName;
        private System.Windows.Forms.Label lblNoOfSeeds;
        private System.Windows.Forms.Label lblSowMonths;
        private System.Windows.Forms.Label lblFlowerMonths;
        private System.Windows.Forms.Label lblAdditionalInformation;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox txtSeedName;
        private System.Windows.Forms.TextBox txtNoOfSeeds;
        private System.Windows.Forms.RichTextBox rtbAdditionalInformation;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.CheckedListBox checkedListBox2;
    }
}