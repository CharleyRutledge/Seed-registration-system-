﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2Seeds
{
    public partial class AddModifySeedForm : Form
    {
        public AddModifySeedForm()
        {
            InitializeComponent();
        }
        public bool AddSeed { get; set; }

        public Seed Seed { get; set; }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void AddModifySeedForm_Load(object sender, EventArgs e)
        {
            if (AddSeed)
            {
                this.Text = "Add Seed";
            }
            else
            {
                this.Text = "Edit Seed";
                this.DisplaySeed();
            }
        }

        public void DisplaySeed()
        {
            txtSeedName.Text = Seed.seedname;
            txtNoOfSeeds.Text = Seed.NoOfSeeds.ToString();
          
            

            if (Seed.SowMonths.Count !=0)
            {
                for (int i = 0; i < Seed.SowMonths.Count; i++)
                {
                    int x = Seed.SowMonths[i];
                    
                    checkedListBox1.SetItemChecked(x-1, true);

                }
            }

            if (Seed.FlowerMonths.Count != 0)
            {
                for (int i = 0; i < Seed.FlowerMonths.Count; i++)
                {
                    int x = Seed.FlowerMonths[i];
                    MessageBox.Show("i" + x);
                    checkedListBox2.SetItemChecked(x - 1, true);

                }
            }

            rtbAdditionalInformation.Text = Seed.OtherInfo;
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (AddSeed) { Seed = new Seed(); }   
            Seed.seedname = txtSeedName.Text;
            Seed.NoOfSeeds = Convert.ToInt32(txtNoOfSeeds.Text);
            Seed.SowMonths = new List<int>();
            Seed.FlowerMonths = new List<int>();
            Seed.FlowerMonthDisplay = "";
            Seed.SowMonthDisplay = "";
            Seed.OtherInfo = rtbAdditionalInformation.Text;
            if (checkedListBox1.CheckedItems.Count !=0)
            {
                for (int i = 0; i <checkedListBox1.CheckedItems.Count; i++)
                {
                    int MonthNumber = checkedListBox1.CheckedIndices[i] + 1;
                    Seed.SowMonths.Add(MonthNumber);
                    Seed.SowMonthDisplay += checkedListBox1.CheckedItems[i].ToString() + "";
                }
            }


            if (checkedListBox2.CheckedItems.Count != 0)
            {
                for (int i = 0; i < checkedListBox2.CheckedItems.Count; i++)
                {
                    Seed.FlowerMonths.Add( checkedListBox2.CheckedIndices[i] + 1);
                    
                    Seed.FlowerMonthDisplay += checkedListBox2.CheckedItems[i].ToString() + "";
                }

            }
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
